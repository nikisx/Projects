﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Guild
{
    public class Guild
    {
        public Guild(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.Roster = new List<Player>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public List<Player> Roster { get; set; }
        public int Count
        {
            get { return this.Roster.Count; }
        }

        public void AddPlayer(Player player)
        {
            if (this.Roster.Count < Capacity)
            {
                this.Roster.Add(player);
            }
        }
        public bool RemovePlayer(string name)
        {
            Player player = this.Roster.FirstOrDefault(x => x.Name == name);
            if (player != null)
            {
                this.Roster.Remove(player);
                return true;
            }
            return false;

            //if (this.Roster.Select(x => x.Name).Contains(name))
            //{
            //    Player player = this.Roster.FirstOrDefault(x => x.Name == name);
            //    this.Roster.Remove(player);
            //    return true;
            //}
            //return false;
        }
        public void PromotePlayer(string name)
        {
            Player player = Roster.FirstOrDefault(x => x.Name == name);
            if (player != null)
            {
                player.Rank = "Member";
            }
        }
        public void DemotePlayer(string name)
        {
            Player player = Roster.FirstOrDefault(x => x.Name == name);
            if (player != null)
            {
                player.Rank = "Trial";
            }
        }
        public Player[] KickPlayersByClass(string @class)
        {
            List<Player> playersToRemove = new List<Player>();
            foreach (Player player in this.Roster)
            {
                if (player.Class == @class)
                {
                    playersToRemove.Add(player);
                }
            }
            foreach (Player item in playersToRemove)
            {
                this.Roster.Remove(item);
            }
            return playersToRemove.ToArray();
        }
        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Players in the guild: {this.Name}");
            foreach (Player player in this.Roster)
            {
                sb.AppendLine(player.ToString());
            }
            return sb.ToString().TrimEnd();
        }

    }
}
